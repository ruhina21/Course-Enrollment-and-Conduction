

<head>
  <meta charset="utf-8">
  <title>Course Knot</title>
  
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
 

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="patterns.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
<style>
  .card-registration .select-input.form-control[readonly]:not([disabled]) {
  font-size: 1rem;
  line-height: 2.15;
  padding-left: .75em;
  padding-right: .75em;
}
.card-registration .select-arrow {
  top: 13px;
}
</style>
</head>
<?php
session_start();
  $db = new mysqli("localhost","root","","2-2");

  if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $password = $_POST['password'];
    $email = $_POST['email'];
     $age = $_POST['age'];
      $gender = $_POST['gender'];
      $grade = $_POST['grade'];
     $post='student';
 $image = $_FILES['image']['name'];
    $image_text = mysqli_real_escape_string($db,$_POST['image_text']);
        $target = "image/".basename($image); 

    $query = "INSERT INTO reg_table(name, password,email,age,gender,grade,image,image_text,post) VALUES ('$name' , '$password', '$email','$age','$gender','$grade','$image','$image_text','$post')";
      mysqli_query($db, $query);
if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      $msg = "Image uploaded successfully";
    }else{
      $msg = "Failed to upload image";
    }

    header('Location: http://localhost/2-2/getstartedS.php');
    
  }

    ?>
<body style="background-image: url('bb.jpg');">
<section class="h-100 bg-dark"style="background-image: url('bb.jpg');">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col">
        <div class="card card-registration my-4">
          <div class="row g-0">
            <div class="col-xl-6 d-none d-xl-block">
              <img
                src="https://mdbootstrap.com/img/Photos/new-templates/bootstrap-registration/img4.jpg"
                alt="Sample photo"
                class="img-fluid"
                style="border-top-left-radius: .25rem; border-bottom-left-radius: .25rem;"
              />
            </div>
            <div class="col-xl-6">
              <div class="card-body p-md-5 text-black">
                <h3 class="mb-5 text-uppercase">Student registration form</h3>
 <form action="login.php" enctype="multipart/form-data" method="POST" class="register-form">
                <div class="row">
                  <div class="col-md-6 mb-4">
                    <div class="form-outline">
                      <input type="text" id="form3Example1m" class="form-control form-control-lg" name="name" required>
                      <label class="form-label" for="form3Example1m">Name</label>
                    </div>
                  </div>
                  <div class="col-md-6 mb-4">
                    <div class="form-outline">
                      <input type="text" id="form3Example1n" class="form-control form-control-lg" name="age" required>
                      <label class="form-label" for="form3Example1n">Age</label>
                    </div>
                  </div>
                </div>

              

                 <div class="mb-4">
  <p class="mb-0 me-4">Grade: 
                <select class="select" name="grade">
                  <option value="1" disabled>Class</option>
                  <option value="class 9-10">class 9-10</option>
                  <option value="HSC-Science group">HSC-Science group</option>
                  <option value="Hsc-Commerce group">Hsc-Commerce group</option>
                  <option value="Hsc Humanities group">Hsc Humanities group</option>
                     
<option value="Medical">Medical</option>
<option value="Electrical Engineering">Electrical Engineering</option>
<option value="Computer Engineering">Computer Engineering</option>
<option value="Civil Engineering">Civil Engineering</option>
<option value="Mechanical Engineering">Mechanical Engineering</option>
<option value="Architecture">Architecture</option>

                </select>
</p>
              </div>

                <div class="d-md-flex justify-content-start align-items-center mb-4 py-2">

                   <div class="mb-4">
  <p class="mb-0 me-4">Gender: 
                <select class="select" name="gender">
                  <option value="male" >male</option>
                  <option value="female">female</option>
                  

                </select>
</p>
              </div>
                  
                </div>

               
                  



                <div class="form-outline mb-4">
                  <input type="text" id="form3Example97" class="form-control form-control-lg" name="email" required>
                  <label class="form-label" for="form3Example97">Email ID</label>
                </div>
                
                <div class="form-outline mb-4">
                  <input type="password" id="form3Example97" class="form-control form-control-lg" name="password" required>
                  <label class="form-label" for="form3Example97">Password</label>
                </div>
               <div class="mb-4">
 
<input type="hidden" name="size" value="1000000">
         <input  class="form-control form-control" type="file" name="image" required > 
          <label class="form-label" for="form3Example97">Upload a Profile Photo</label>
       </div>
           <textarea 
        id="text" 
        cols="40" 
        rows="4" 
        name="image_text" 
        placeholder="Say something about You..."></textarea>
        <br><br>
         <button  name="submit">Create</button>
        </div>
                <div class="">
                  
                 

                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
     
    </div>
  </div>
</div>

</section>
<script src='http://code.jquery.com/jquery-3.3.1.min.js'></script>
  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstarp.min.js"></script>
  <script src="js/custom.js"></script>

  <script>
    $('.message a').click(function(){
      $('form').animate({height: "toggle",opacity: "toggle"}, "slow");
    });
  </script>
  
</body>

</html>
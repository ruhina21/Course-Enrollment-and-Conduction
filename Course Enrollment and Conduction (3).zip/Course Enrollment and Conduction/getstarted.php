<?php
   ob_start();
   session_start();
?>

<?
   // error_reporting(E_ALL);
   // ini_set("display_errors", 1);
?>
<!DOCTYPE html>

<head>
	<title>Course Knot</title>
	<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
 

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="part.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
</head>
<body>
<header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

    
     
      <a href="getstarted.php"  class="logo me-auto"><img style="height: 90px;  border-radius: 50%" src="logo.jpg" alt="" ></a>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="active" href="getstarted.php">Home</a></li>
          <li><a href="teacherProfile.php">Profile</a></li>
           <li><a href="about.php">Activities</a></li>
 <li><a  href="course.php">Courses</a></li>
          <li><a  href="trainer.php">Trainers</a></li>
          <li><a href="event.php">Events</a></li>
          <li><a href="stud.php">Students</a></li>

         
   
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
       </nav><!-- .navbar -->

     <!--<a href="frontpage.php" class="get-started-btn">Login</a>
<form action="login.php" method="post" class="login-form"> -->
       <div> 







     

   <a  class="get-started-btn" href="logout.php" >Log Out</a>

<?php

  
  $db = new mysqli("localhost","root","","2-2");
 
   if(isset($_POST['login'])){
    $name = $_POST['name'];
    $password = $_POST['password'];

    $mysqli = new mysqli("localhost","root","","2-2");
    $result = $mysqli->query("SELECT * FROM reg_table WHERE name = '$name' AND password ='$password' ");
    $row = $result->fetch_assoc();

    if($row['name'] == $name && $row['password'] == $password)
    {
       $_SESSION['user_name'] = $name;
     
      $message = "Login successful.!";
  //header('Location: http://localhost/2-2/teacherProfile.php');
  
      echo "<script type='text/javascript'>alert('$message');</script>";
     //  $_SESSION['user_name'] = $username;
      
    }
    else{
      $message1 = "Login Unsuccessful.!";
      echo "<script type='text/javascript'>alert('$message1');</script>";
    }
     }

?>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>




    </div>
  </header><!-- End Header -->
   <section id="hero" style="width: 100%;
  height: 100vh ;background-size: cover;
  ;background-image: url('learn.png')" class="d-flex justify-content-center align-items-center">
    <div class="container  position-relative " data-aos="zoom-out" data-aos-delay="100">
      <br>
      <br><br>
      <h1 >Celebrating the power of knowledge</h1>
      <h2 >We are here to help you explore the world of knowledge just the way you want it to be. <br>So what's next? Just enjoy this trip to your best dream!</h2>
      
    </div>
  </section>
 <section id="counts" class="counts section-bg">
      <div class="container">

        <div class="row counters">

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="1232" data-purecounter-duration="1" class="purecounter"></span>
            <p>Students</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="64" data-purecounter-duration="1" class="purecounter"></span>
            <p>Courses</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="42" data-purecounter-duration="1" class="purecounter"></span>
            <p>Events</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="15" data-purecounter-duration="1" class="purecounter"></span>
            <p>Trainers</p>
          </div>

        </div>

      </div>
    </section>
  <main id="main">

 
        <section id="why-us" class="why-us">
      <div class="container" data-aos="fade-up">

        <div class="row">
        
          <div class="col-lg-6 d-flex align-items-stretch">
            <div class="content">
              <h3>Why COURSE KNOT?</h3>
              <p>
               
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit
                Asperiores dolores sed et. Tenetur quia eos. Autem tempore quibusdam vel necessitatibus optio ad corporis.
              </p>
              <div class="text-center">
                <a href="#" class="more-btn">Learn More <i class="bx bx-chevron-right"></i></a>
              </div>
            </div>
          </div>
            <div class="col-lg-6 d-flex align-items-stretch">
            <img style="height:500px;width: 600px" src="teacher.jpg">
          </div>
        </div>
          <div class="col-lg-8 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-boxes d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-receipt"></i>
                    <h4>Corporis voluptates sit</h4>
                    <p>Consequuntur sunt aut quasi enim aliquam quae harum pariatur laboris nisi ut aliquip</p>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-cube-alt"></i>
                    <h4>Ullamco laboris ladore pan</h4>
                    <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt</p>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-images"></i>
                    <h4>Labore consequatur</h4>
                    <p>Aut suscipit aut cum nemo deleniti aut omnis. Doloribus ut maiores omnis facere</p>
                  </div>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section>
    
     
        <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>COURSE KNOT</h3>
            <p>
              Muradnagar Street <br>
             Ashulia, Savar<br>
              Dhaka<br><br>
              <strong>Phone:</strong> +880 1614-731003<br>
              <strong>Email:</strong> courseknot@gmail.com.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="course.php">Courses</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="event.php">Events</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="trainer">Trainers</a></li>
              
            </ul>
          </div>
     

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Us</h4>
            <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
           
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        
        
      </div>
    
        
    </div>
  </footer>
      <script src="vendor/purecounter/purecounter.js"></script>
  <script src="vendor/aos/aos.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/swiper/swiper-bundle.min.js"></script>
  <script src="vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="js/main.js"></script>
</body>
</html>
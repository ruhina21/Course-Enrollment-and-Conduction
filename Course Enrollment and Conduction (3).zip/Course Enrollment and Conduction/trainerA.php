<!DOCTYPE html>

<head>
	<title>Course Knot</title>
	  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
 

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="pattarn.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
</head>
<body>
<header id="header" style="background-color: #0e062e" class="fixed-top">
    <div class="container d-flex align-items-center">

  
     
      <a href="getA.php"  class="logo me-auto"><img style="height: 90px;  border-radius: 50%" src="logo.jpg" alt="" ></a>

      <nav id="navbar" class="navbar order-last order-lg-0 " >
        <ul>
          <li><a  href="getA.php">Home</a></li>
          
          <li><a  href="courseA.php">Courses</a></li>
          <li><a class="active" href="trainerA.php">Trainers</a></li>
          <li><a href="eventA.php">Events</a></li>
        
     <li><a href="contact.php">Contact</a></li>
        
            
        
       
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    <a  class="get-started-btn" style="background-color:  #5585c9" href="logout.php" >Log Out</a>


</div>
</header>
</div>
    </div>
    <br><br><br><br><br>

    <?php 

$localhost = "localhost"; 
$dbusername = "root"; #username of phpmyadmin
$dbpassword = "";  #password of phpmyadmin
$dbname = "2-2";  #database name
$conn = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);

?>
  <section id="crs" >
     <div class="section-title py-3">
        <h1 class="text-center" style="text: #c30c02">OTHER TRAINERS</h1>
        </div>
   
    <div class="row  mx-2" >
         
          <?php
$query9=mysqli_query( $conn,"SELECT * from  reg_table where post='teacher'");
$rowcount2=mysqli_num_rows($query9);

  for($j=0;$j<$rowcount2;$j++)
{
  $row=mysqli_fetch_array($query9);


?>
 <div class="col-md-3" style="float: center;"  >

  <div class="card" style="width: 22rem; margin-top: 50px">
      <?php echo "<img src='image/".$row['image']."'  >";?>
 
  <div class="card-body" style="background-color:#d3d8ed ">
    <h5 class="card-title"><?php echo $row["name"] ;?></h5>
   <p class="card-text"><?php echo $row["subject"] ;?></p> 
   <p style="color:grey" >4 running courses</p>
   <p style="color: green" >Rating: 4.5<i class="fas fa-star"></i></p>
    <a class="btn btn-info "  data-toggle="popover" style="color: white" data-content="<?php echo $row["image_text"] ;?>"> <b>Details</b>  
  </a>
      
 
  </div>
</div>
</div>
<?php
}
?>

</section>
</body>
<script>
$(document).ready(function(){
  $('[data-toggle="popover"]').popover();   
});
</script>
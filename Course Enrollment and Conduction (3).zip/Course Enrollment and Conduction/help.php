 <?php

   ob_start();
   session_start();
?>
 <!DOCTYPE html>

<head>
  
  <title>Course Knot</title>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
 

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="crspat.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

 <style >
   
 <style >
 body {
    background-color: #f9f9fa
}

n-out
}
 </style>
</style>
</head>
 <body>
<?php 

$localhost = "localhost"; #localhost
$dbusername = "root"; #username of phpmyadmin
$dbpassword = "";  #password of phpmyadmin
$dbname = "2-2";  #database name
 
#connection string

$conn = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);

$localhost = "localhost"; #localhost
$dbusername = "root"; #username of phpmyadmin
$dbpassword = "";  #password of phpmyadmin
$dbname = "2-2";  #database name
 
#connection string

$conn2 = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);

?>
 
           <?php

  $db = new mysqli("localhost","root","","2-2");

 if(isset($_POST['submit'])){
    $names = $_POST['names'];
    $courseid= $_POST['courseid'];
   


    $query = "INSERT INTO enrollment(names,courseid) VALUES ('$names' , '$courseid')";
      mysqli_query($db, $query);

    header('Location: http://localhost/2-2/help.php');
  }

    ?>    
   
         
     <?php
$bookwriter=$_SESSION['user_name'];

$query2=mysqli_query($conn,"SELECT * from reg_table WHERE name='$bookwriter'");
$stl= mysqli_fetch_array($query2);
?>
    <div class="row  mx-2" >
         
          <?php
$query9=mysqli_query( $conn,"SELECT * from  coursetable ");
$rowcount2=mysqli_num_rows($query9);

  for($j=0;$j<$rowcount2;$j++)
{
  $row=mysqli_fetch_array($query9);


?>
     
               
 <form action="help.php" enctype="multipart/form-data" method="POST" class="register-form">
          
        
<br>
       <input type="hidden" name="names" value="<?php echo $_SESSION['user_name']; ?>">
      <input type="hidden" name="courseid" value="<?php echo " ".$row['id'] ;?>">

 
                  <button name="submit">Create Profile</button>
                </form>
 </div>
  <?php
}
    ?>
   
               
               </div> 

              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
     
 
                                    </div>
                              



</div>





    
</div>
</main>
 


  </body>

</html>
export class FormModel{
  pid: any;
  pname: any;
  description: any;
  image: any;
  price: any;
  discount: any;
  isdiscount: Boolean = true;
  isavailable: Boolean = true;
}
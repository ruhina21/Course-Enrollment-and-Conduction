 <?php

   ob_start();
   session_start();
?>
 <!DOCTYPE html>

<head>
  
  <title>Course Knot</title>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
 

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="crspat.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

 <style >
   
 <style >
 body {
    background-color: #f9f9fa
}

.padding {
    padding: 3rem !important
}

.user-card-full {
    overflow: hidden
}

.card {
  float: center;
  width: 1200px;
  height: 800px;
    border-radius: 5px;
    -webkit-box-shadow: 0 1px 20px 0 rgba(69, 90, 100, 0.08);
    box-shadow: 0 1px 20px 0 rgba(69, 90, 100, 0.08);
    border: none;
display: block;
margin-left: auto;
margin-right: auto;
margin-top: 100px;
}

.m-r-0 {
    margin-right: auto
}

.m-l-0 {
    margin-left: auto;
}

.user-card-full .user-profile {
    border-radius: 5px 0 0 5px
}

.bg-c-lite-green {
    background: -webkit-gradient(linear, left top, right top, from(#0a0e2b), to(#66a0d4));
    background: linear-gradient(to right, #0a0e2b, #0a0e2b)
}

.user-profile {
    padding: 300px 0
}

.card-block {

    padding: 1.25rem
}

.m-b-25 {
    margin-bottom: 25px
}

.user-profile img {

    border-radius: 50%;
    height: 200px;
    width: 200px;
}

h6 {
    font-size: 16px
}

.card .card-block p {
    line-height: 25px
}

@media only screen and (min-width: 1400px) {
    p {
        font-size: 14px
    }
}

.card-block {
    padding: 1.25rem
}

.b-b-default {
    border-bottom: 1px solid #e0e0e0
}

.m-b-20 {
    margin-bottom: 20px
}

.p-b-5 {
    padding-bottom: 5px !important
}

.card .card-block p {
    line-height: 25px
}

.m-b-10 {
    margin-bottom: 10px
}

.text-muted {
    color: #919aa3 !important
}

.b-b-default {
    border-bottom: 1px solid #121026
}

.f-w-600 {
    font-weight: 600
}

.m-b-20 {
    margin-bottom: 20px
}

.m-t-40 {
    margin-top: 20px
}

.p-b-5 {
    padding-bottom: 5px !important
}

.m-b-10 {
    margin-bottom: 10px
}

.m-t-40 {
    margin-top: 20px
}

.user-card-full .social-link li {
    display: inline-block
}

.user-card-full .social-link li a {
    font-size: 20px;
    margin: 0 10px 0 0;
    -webkit-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out
}
 </style>
</style>
</head>
 <body>
<?php 

$localhost = "localhost"; #localhost
$dbusername = "root"; #username of phpmyadmin
$dbpassword = "";  #password of phpmyadmin
$dbname = "2-2";  #database name
 
#connection string

$conn = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);

$localhost = "localhost"; #localhost
$dbusername = "root"; #username of phpmyadmin
$dbpassword = "";  #password of phpmyadmin
$dbname = "2-2";  #database name
 
#connection string

$conn2 = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);

?>
 
     
      <?php
$bookwriter=$_SESSION['user_name'];

$query2=mysqli_query($conn,"SELECT * from reg_table WHERE name='$bookwriter'");
$stl= mysqli_fetch_array($query2);
?>
<?php

  $db = new mysqli("localhost","root","","2-2");

 if(isset($_POST['submit'])){
    $title = $_POST['title'];
    $trainer = $_POST['trainer'];
    //$email = $_POST['email'];
     //$age = $_POST['age'];
    $start = $_POST['start'];
      $category = $_POST['category'];
      $subject = $_POST['subject'];
      $email=$_POST['email'];
      // $post='teacher';
 $image = $_FILES['image']['name'];
    $image_text = mysqli_real_escape_string($db,$_POST['image_text']);
        $target = "image/".basename($image); 

    $query = "INSERT INTO coursetable(title, trainer,category,subject,image,image_text,start,email) VALUES ('$title' , '$trainer', '$category','$subject','$image','$image_text','$start','$email')";
      mysqli_query($db, $query);
if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      $msg = "Image uploaded successfully";
    }else{
      $msg = "Failed to upload image";
    }
    header('Location: http://localhost/2-2/teacherProfile.php');
  }

    ?>     

    <?php

  $db = new mysqli("localhost","root","","2-2");

 if(isset($_POST['event'])){
    $title = $_POST['title'];
    $trainer = $_POST['trainer'];  
    $start = $_POST['start'];
      $category = $_POST['category'];    
 $image = $_FILES['image']['name'];
    $image_text = mysqli_real_escape_string($db,$_POST['image_text']);
        $target = "image/".basename($image); 

    $query = "INSERT INTO eventtable(title, trainer,category,image,image_text,start) VALUES ('$title' , '$trainer', '$category','$image','$image_text','$start')";
      mysqli_query($db, $query);
if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      $msg = "Image uploaded successfully";
    }else{
      $msg = "Failed to upload image";
    }
    header('Location: http://localhost/2-2/teacherProfile.php');
  }

    ?>     
 <body style="background-color:white" >
    
     
  <header id="header" style="background-color: #0e062e" class="fixed-top">
    <div class="container d-flex align-items-center"> 

    
     
      <a href="getstarted.php"  class="logo me-auto"><img style="height: 90px;  border-radius: 50%" src="logo.jpg" alt="" ></a>

      <nav id="navbar" class="navbar order-last order-lg-0 " >
        <ul>
          <li><a  href="getstarted.php">Home</a></li>
   <li><a href="teacherProfile.php" class="active">Profile</a></li>
    <li><a href="about.php">Activities</a></li>
          <li><a  href="course.php">Courses</a></li>
          <li><a href="trainer.php">Trainers</a></li>
          <li><a href="event.php">Events</a></li>
           <li><a  href="stud.php">Students</a></li>

      
     
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

<a  class="get-started-btn" style="background-color:  #5585c9" href="logout.php" >Log Out</a>

</div>
</header>

<div class="center" id="page-content">
    <div class="padding">
        <div class="row container d-flex justify-content-center">
            <div class="col-xl-6 col-md-12">
                <div class="card user-card-full">
                    <div class="row m-l-0 m-r-0">
                        <div class="col-sm-4 bg-c-lite-green user-profile">
                            <div class="card-block text-center text-white">
                                <div class="m-b-25">
  <?php echo "<img src='image/".$stl['image']."' >";
?>

                                 </div>
                                <h6 class="f-w-600"><?php echo " ".$stl['name'] ;?></h6>
                                <p><?php echo "".$stl['image_text'] ;?></p> <i class=" mdi mdi-square-edit-outline feather icon-edit m-t-10 f-16"></i>
                            </div>
                        </div>
                        <div style="background-color: #bbbaff;
" class="col-sm-8">
<br>
<br>
                        <div style="margin-top: 80px " >
                            <div class="card-block">
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h6>
                                 <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Subject</p>
                                        <h6 class="text-muted f-w-400"><?php echo " ".$stl['subject'] ;?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Gender</p>
                                         <h6 class="text-muted f-w-400"><?php echo " ".$stl['gender'] ;?></h6>
                                       
                                    </div>
                                </div>
                               
                                  <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Email</p>
                                        <h6 class="text-muted f-w-400"><?php echo " ".$stl['email'] ;?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                      <p class="m-b-10 f-w-600">Joined On</p>
                                         <h6 class="text-muted -w-400"><?php echo " ".$stl['date'] ;?></h6>
                                    </div>
                                </div>

                              <br><br>
                                <h6 class="m-b-20 m-t-40 p-b-5 b-b-default f-w-600">Courses</h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Recent</p>
                                        <h6 class="text-muted f-w-400">Sam Disuja</h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Most Viewed</p>
                                        <h6 class="text-muted f-w-400">Dinoter husainm</h6>
                                    </div>
                                </div>
                                <br>
                                <br><br>
                                   <h6 class="m-b-20 p-b-5 b-b-default f-w-600">Upload
                                   </h6>
                                                                <div class="row">
                                    <div class="col-sm-6">
                                      
                                      <button onclick="document.getElementById('id01').style.display='block'" name="login"  style="width:auto;background-color:  #0a0e2b" class=" btn-info">Upload a Course</button>                                    </div>
                                    <div class="col-sm-6">
                                       
                                        <button onclick="document.getElementById('id02').style.display='block'" name="hh"  style="width:auto;background-color:  #0a0e2b" class=" btn-info">Upload an Event</button>
 
                                    </div>
                                </div>
                                                              <br><br>
                               
                                <div class="row">
                                    <div class="col-sm-6">
                                   
                                    </div>
                                    
                                </div>
                                <ul class="social-link list-unstyled m-t-40 m-b-10">
                                    <li><a href="#!" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="facebook" data-abc="true"><i class="mdi mdi-facebook feather icon-facebook facebook" aria-hidden="true"></i></a></li>
                                    <li><a href="#!" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="twitter" data-abc="true"><i class="mdi mdi-twitter feather icon-twitter twitter" aria-hidden="true"></i></a></li>
                                    <li><a href="#!" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="instagram" data-abc="true"><i class="mdi mdi-instagram feather icon-instagram instagram" aria-hidden="true"></i></a></li>
                                </ul>
                              <div>

 
 

<div id="id01" class="modal" width:500px>
  <form action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); 
            ?>" enctype="multipart/form-data" method="post" class="modal-content animate" style="width: 1000px">

    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal" >&times;</span>
      <img style="height: 90px;  border-radius: 50%" src="logo.jpg" alt="" class="avatar">
    </div>

    <div class="container">
     
      <input type="text" placeholder="Enter Title" placeholder="Course Title" name="title" required>
<input type="hidden" name="trainer" value="<?php echo $_SESSION['user_name']; ?>">
<input type="hidden" name="subject" value="<?php echo " ".$stl['subject'] ;?>">
<input type="hidden" name="email" value="<?php echo " ".$stl['email'] ;?>">
<div class="row">
  <div class="col-lg-2">
      <label for="category"><b>Category:</b></label>
      <select class="select" name="category">
                  <option value=" " >---</option>
                  <option value="Paid">Paid</option>
                  <option value="Unpaid">Unpaid</option>
          </select>
</div>
      <div class="col-lg-2">               
         <label for="start"><b>Starts On:</b></label>
      <input type="date"  name="start"  >
</div>
<div  class="col-lg-8">
<input type="hidden" name="size" value="1000000">
<label for="image"><b>Related Photo:</b></label>
          <input  class="form-control form-control" type="file" name="image" > 
        </div>
        </div>
      <p>
    
      <input type="text" placeholder="Course Details..." name="image_text" required> 
    </p>
  
      <button style="background-color: #0a0e2b" type="submit" name="submit">Submit</button>
      
    
</div>

   
  </form>


</div>


<div id="id02" class="modal" width:500px>
  <form action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); 
            ?>" enctype="multipart/form-data" method="post" class="modal-content animate" style="width: 1000px">

    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal" >&times;</span>
      <img style="height: 90px;  border-radius: 50%" src="logo.jpg" alt="" class="avatar">
    </div>

    <div class="container">
     
      <input type="text" placeholder="Enter Title" placeholder="Course Title" name="title" required>
<input type="hidden" name="trainer" value="<?php echo $_SESSION['user_name']; ?>">

<div class="row">
  <div class="col-lg-2">
      <label for="category"><b>Category:</b></label>
      <select class="select" name="category">
                  <option value=" " >---</option>
                  <option value="Paid">Paid</option>
                  <option value="Unpaid">Unpaid</option>
          </select>
</div>
      <div class="col-lg-2">               
         <label for="start"><b>Date:</b></label>
      <input type="date"  name="start"  >
</div>
<div  class="col-lg-8">
<input type="hidden" name="size" value="1000000">
<label for="image"><b>Related Photo:</b></label>
          <input  class="form-control form-control" type="file" name="image" > 
        </div>
        </div>
      <p>
    
      <input type="text" placeholder="Event Details..." name="image_text" required> 
    </p>
  
      <button style="background-color: #0a0e2b" type="submit" name="event">Submit</button>
      
    
</div>

   
  </form>


</div>
<script>
// Get the modal
var modal = document.getElementById('id01');
var modal = document.getElementById('id02');
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>




    </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</main>
 

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
  </body>

</html>
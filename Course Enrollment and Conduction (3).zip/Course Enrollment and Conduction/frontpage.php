<!DOCTYPE html>
<html>
<head>
	<title>COURSE KNOT</title>
	  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-image: url('bb.jpg');">
	<div style="text-align: center; position: absolute;
  top: 45%;
  left: 45%;
  margin: -25px 0 0 -25px;">
<button type="button" style="border-radius: 4px" class="btn btn-info "><a href="login.php"><h4>Register as a Student</h4></a></button><br><br>
<button type="button" style="border-radius: 4px"  class="btn btn-info"><a href="tlogin.php"><h4>Register as a Tutor</h4></button>
</div>
</body>
</html>